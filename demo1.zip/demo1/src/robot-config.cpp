#include "vex.h"

using namespace vex;

// A global instance of brain used for printing to the V5 brain screen
brain Brain;

motor LeftHookMotor = motor(PORT10, ratio18_1, false);
motor RightHookMotor = motor(PORT20, ratio18_1, true);

vex::controller Controller1 = vex::controller();

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 *
 *Code Source:
 *https://kb.vex.com/hc/en-us/articles/360035593152-Arcade-Control-VEX-C-
 */
void vexcodeInit(void) {
  Brain.Screen.print("Demo 1: Motors");
  wait(200, msec);

  while (true) {          
        LeftHookMotor.spin(directionType::fwd, (Controller1.Axis3.value() + Controller1.Axis4.value())/2, velocityUnits::pct); //(Axis3+Axis4)/2;
        RightHookMotor.spin(directionType::fwd, (Controller1.Axis3.value() - Controller1.Axis4.value())/2, velocityUnits::pct);//(Axis3-Axis4)/2;

        task::sleep(20);
    } 

}